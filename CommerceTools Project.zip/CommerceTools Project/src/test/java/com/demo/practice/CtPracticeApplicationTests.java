package com.demo.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
