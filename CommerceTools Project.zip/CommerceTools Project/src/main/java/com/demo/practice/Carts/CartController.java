package com.demo.practice.Carts;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.cart.Cart;
import com.commercetools.api.models.cart.CartPagedQueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    CartService cartService;
    @Autowired
    ProjectApiRoot apiRoot;

    @PostMapping("/create")
    public Cart createCart(@RequestBody CartData cartData) {
        return cartService.createCart(cartData);
    }
    @GetMapping("/get/{id}")
    public Cart getCartById(@PathVariable String id){
        return apiRoot.carts().withId(id).get().executeBlocking().getBody();
    }
    @GetMapping("/all")
    public CartPagedQueryResponse getAll(){
        return apiRoot.carts().get().executeBlocking().getBody();
    }
    @DeleteMapping("/delete/{id}")
    public Cart deleteByID(@PathVariable String id){
        return apiRoot.carts().withId(id).delete(1).executeBlocking().getBody();
    }
}
