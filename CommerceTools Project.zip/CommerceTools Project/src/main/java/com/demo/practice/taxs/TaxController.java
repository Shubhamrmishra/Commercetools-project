package com.demo.practice.taxs;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.tax_category.TaxCategory;
import com.commercetools.api.models.tax_category.TaxCategoryPagedQueryResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/tax")
public class TaxController {

    @Autowired
    ProjectApiRoot apiRoot;
    @Autowired
    TaxService taxService;
    @PostMapping("/create")
    public TaxCategory createTax(@RequestBody TaxData taxData){

        return taxService.createTax(taxData);
    }

    @GetMapping("/get")
    public TaxCategoryPagedQueryResponse getAllTaxes(){
        return apiRoot.taxCategories().get().executeBlocking().getBody();
    }
    @GetMapping("/get/{id}")
    public TaxCategory getTaxByID(@PathVariable String id){
        return apiRoot.taxCategories().withId(id).get().executeBlocking().getBody();
    }
    @DeleteMapping("/delete/{id}/{ver}")
    public TaxCategory deleteTaxByID(@PathVariable String id, @PathVariable int ver){
        return apiRoot.taxCategories().withId(id).delete().withVersion(ver).executeBlocking().getBody();
    }
}
