package com.demo.practice.products;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ProductData {
    public String Id;
    public String productName;
    public String key;
    public String Slug;
    public long version;
    public String Sku;
    public String Description;
    public String currencyCode;
    public long centAmount;
    public String Url;
    public String label;
    public int W;
    public int H;
    public Boolean isPublish;
    public String channelKey;
    public String taxCategoryKey;
    List<ProductAttributesData> productAttributes;






}
