package com.demo.practice.taxs;


import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.tax_category.*;
import com.demo.practice.clientD.Client;
import com.demo.practice.products.ProductDataProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaxService {

    ProjectApiRoot projectApiRoot = Client.createApiClient();
    TaxDataProvider tdp = new TaxDataProvider();

    public TaxCategory createTax(TaxData taxData){
        TaxCategoryDraft categoryDraft =TaxCategoryDraft
                .builder().key(taxData.getKey()).name(taxData.getName())
                .description(taxData.getDescription())
                .rates(TaxRateDraft.builder().state(taxData.getState()).name(taxData.getRateName())
                        .country(taxData.getCountry()).amount(taxData.getAmount())
                        .includedInPrice(taxData.getInCludedInPrice()).build())
                .build();

        return tdp.createTax(categoryDraft);

//      //  TaxCategory taxCategory=TaxCategory
//                .builder().name(taxData.getName())
//                .key(taxData.getKey())
//                .description(taxData.getDescription())
//               // .rates(TaxRateBuilder.of().name(taxData.getRateName()).amount(taxData.getAmount())
//                        .country(taxData.getCountry()).state(taxData.getState())
//                        .includedInPrice(taxData.getInCludedInPrice()).build())
//                .build();
        //return pdp.createTax(taxCategory);

    }

}
