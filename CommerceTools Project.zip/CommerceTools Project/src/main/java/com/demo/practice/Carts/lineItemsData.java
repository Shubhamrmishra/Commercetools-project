package com.demo.practice.Carts;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class lineItemsData {
    public String sku;

}
