package com.demo.practice.taxs;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TaxData {
    public String name;
    public String key;
    public String country;
    public double amount;
    public Boolean inCludedInPrice;
    public String state;
    public String rateName;
    public String Description;


}
