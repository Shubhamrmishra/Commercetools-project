package com.demo.practice.stores;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class StoreData {
    public String storeName;
    public String storeKey;
    public String channelId;
    public String country;
    public String Language;
    public String productSelection;
}
