package com.demo.practice.Login;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.customer.Customer;
import com.commercetools.api.models.customer.CustomerSignInResult;
import com.commercetools.api.models.customer.CustomerToken;
import com.demo.practice.customers.CustomerData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/customer")
public class LoginController {
    @Autowired
    ProjectApiRoot projectApiRoot;

    @Autowired
    LoginService service;
    @PostMapping("/reset-token")
    public CustomerToken createToken(@RequestBody CustomerData data){

        return service.createToken(data);
    }

    @PostMapping("/reset-token/password")
    public Customer resetCustomerPassword(@RequestBody CustomerData data){
        return service.resetCustomerPassword(data);
    }
    @PostMapping("/change/password")
    public Customer ChangeCustomerPassword(@RequestBody CustomerData data){
        return service.ChangeCustomerPassword(data);
    }

    @GetMapping("/login")
    public CustomerSignInResult customerLogin(@RequestBody CustomerData data){

        return service.customerLogin(data);
    }


}
