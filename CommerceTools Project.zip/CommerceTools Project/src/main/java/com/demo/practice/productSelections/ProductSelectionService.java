package com.demo.practice.productSelections;

import com.commercetools.api.models.common.LocalizedString;
import com.commercetools.api.models.product_selection.ProductSelection;
import com.commercetools.api.models.product_selection.ProductSelectionDraft;
import com.demo.practice.productSelections.ProductSelectionData;
import com.demo.practice.products.ProductDataProvider;
import org.springframework.stereotype.Service;

@Service
public class ProductSelectionService {


    ProductSelectionDataProvider psdp;
    public ProductSelection createProductSelection(ProductSelectionData productSelectionData){
        ProductSelectionDraft productSelectionDraft = ProductSelectionDraft.builder()
                .key(productSelectionData.getKey()).name(LocalizedString.ofEnglish(productSelectionData.getName()))
                .build();

        return psdp. createProductSelection(productSelectionDraft);
    }
}
