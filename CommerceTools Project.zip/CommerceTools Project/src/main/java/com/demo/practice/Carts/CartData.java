package com.demo.practice.Carts;

import com.commercetools.api.models.cart.TaxMode;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CartData {
    public  String currency;
    public TaxMode taxMod;
    public String customerEmail;
    public String customerId;
   List<lineItemsData> lineItems;
}
