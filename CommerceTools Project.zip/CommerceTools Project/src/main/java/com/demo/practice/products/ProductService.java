package com.demo.practice.products;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.channel.ChannelResourceIdentifier;
import com.commercetools.api.models.common.*;
import com.commercetools.api.models.product.*;
import com.commercetools.api.models.product_type.*;
import com.commercetools.api.models.tax_category.TaxCategoryResourceIdentifier;
import com.demo.practice.clientD.Client;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {


    ProjectApiRoot apiRoot = Client.createApiClient();
    ProductDataProvider pdp = new ProductDataProvider();

    public ProductType createProductType(ProductTypeData productTypeData) {
        List<AttributeDefinitionDraft> AtList = productTypeData.getAttributes().stream()
                .map(attributesData -> {

                    return AttributeDefinitionDraft.builder()
                            .type(attributesData.getAttributeType())
                            .name(attributesData.getAttributeName())
                            .label(LocalizedString.ofEnglish(attributesData.getLabel()))
                            .attributeConstraint(attributesData.getAttributeConstraint())
//                            .inputTip(LocalizedString.ofEnglish(attributesData.getInputTip()))
//                            .inputHint(TextInputHint.findEnum(attributesData.getInputHint()))
                            .isRequired(attributesData.getIsRequired())
                            .isSearchable(attributesData.getIsSearchable())
                            .build();
                }).collect(Collectors.toList());

        ProductTypeDraft typeDraft = ProductTypeDraft.builder()
                .key(productTypeData.getKey())
                .description(productTypeData.getDescription())
                .name(productTypeData.getName())
                .attributes(AtList)
                .build();
        return pdp.createProductType(typeDraft);
    }

    // Create Product

    public Product createProduct(com.demo.practice.products.ProductData productData) {

        List<Attribute> attributeDraft = productData.getProductAttributes().stream()
                .map(productAttributesData -> {

                    return AttributeBuilder.of().name(productAttributesData.getAttributeName())
                            .value(productAttributesData.getAttributeValue()).build();
                }).collect(Collectors.toList());

        ProductDraft productDraft = ProductDraft.builder()
                .productType(ProductTypeResourceIdentifier.builder()
                        .id(productData.getId()).build())
                .name(LocalizedString.ofEnglish(productData.getProductName()))
                .key(productData.getKey())
                .description(LocalizedString.ofEnglish(productData.getDescription()))
                .slug(LocalizedString.ofEnglish(productData.getSlug()))
                .masterVariant(ProductVariantDraftBuilder.of()

                        .prices(PriceDraft.builder()
                                .value(Money.builder().centAmount(productData.getCentAmount())
                                        .currencyCode(productData.getCurrencyCode()).build())
                                .channel(ChannelResourceIdentifier.builder().key(productData.getChannelKey()).build())

                                .build())
                        .sku(productData.getSku())
                        .key(productData.getKey())
                        .images(Image.builder()
                                .url(productData.getUrl())
                                .dimensions(ImageDimensions.builder().h(productData.getH()).w(productData.getW()).build())
                                .build())
                        .attributes(attributeDraft)
                        .build())

                .publish(productData.getIsPublish())
                .taxCategory(TaxCategoryResourceIdentifier.builder().key(productData.getTaxCategoryKey()).build())
                .build();
        return pdp.createProduct(productDraft);

    }


    //Update product

    public Product updateProducts(ProductData productData, String id) {
//
        ProductUpdate productUpdate = ProductUpdate.builder()
                .version(productData.getVersion())
                .plusActions(ProductUpdateActionBuilder.of().setKeyBuilder().key(productData.getKey()).build())
//                .plusActions(ProductUpdateActionBuilder.of().addPriceBuilder()
//                        .price(PriceDraft.builder().value(Money.builder().centAmount(productData.getCentAmount()).currencyCode(productData.getCurrencyCode())
//                                .build()).build()).build())
                .build();

        return pdp.updateProducts(productUpdate, id);
    }

}




