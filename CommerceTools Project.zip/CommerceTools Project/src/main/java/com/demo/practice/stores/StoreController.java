package com.demo.practice.stores;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.store.Store;
import com.commercetools.api.models.store.StorePagedQueryResponse;
import com.demo.practice.clientD.Client;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/store")
public class StoreController {

    @Autowired
    ProjectApiRoot apiRoot = Client.createApiClient();
    @Autowired
    StoreService storeService;
    @PostMapping("/create")
    public Store storecreateStore(@RequestBody StoreData storeData){
        return storeService.createStore(storeData);
    }
    @GetMapping("/get")
    public StorePagedQueryResponse getAll(){
        return apiRoot.stores().get().executeBlocking().getBody();
    }
    @GetMapping("/get/{id}")
    public Store getByID(@PathVariable String id){
        return apiRoot.stores().withId(id).get().executeBlocking().getBody();
    }
    @DeleteMapping("/delete/{id}/{ver}")
    public Store deleteStoreByID(@PathVariable String id, @PathVariable int ver){
        return apiRoot.stores().withId(id).delete().withVersion(ver).executeBlocking().getBody();
    }
}
