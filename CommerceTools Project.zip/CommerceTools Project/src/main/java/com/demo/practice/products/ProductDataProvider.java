package com.demo.practice.products;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.product.Product;
import com.commercetools.api.models.product.ProductDraft;
import com.commercetools.api.models.product.ProductUpdate;
import com.commercetools.api.models.product_selection.ProductSelection;
import com.commercetools.api.models.product_selection.ProductSelectionDraft;
import com.commercetools.api.models.product_type.ProductType;
import com.commercetools.api.models.product_type.ProductTypeDraft;
import com.commercetools.api.models.store.Store;
import com.commercetools.api.models.store.StoreDraft;
import com.commercetools.api.models.tax_category.TaxCategory;
import com.commercetools.api.models.tax_category.TaxCategoryDraft;
import com.demo.practice.clientD.Client;

public class ProductDataProvider {


    ProjectApiRoot apiRoot = Client.createApiClient();

    public ProductType createProductType(ProductTypeDraft typeDraft) {
        return apiRoot.productTypes().post(typeDraft).executeBlocking().getBody();
    }

    public Product createProduct(ProductDraft productDraft) {
        return apiRoot.products().post(productDraft).executeBlocking().getBody();
    }


    public Product updateProducts(ProductUpdate productUpdate, String id) {
        return apiRoot.products().withId(id).post(productUpdate).executeBlocking().getBody();

    }



}
