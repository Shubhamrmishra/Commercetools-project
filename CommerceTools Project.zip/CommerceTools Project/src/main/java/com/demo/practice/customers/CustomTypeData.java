package com.demo.practice.customers;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CustomTypeData {

    // field defenation
    public String fieldName;
    public String fieldLabel;
    public Boolean required;
    public Object customType;

    // type draft

    public String typeKey;
    public String typeName;

}
