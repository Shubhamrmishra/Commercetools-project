package com.demo.practice.products;

import com.demo.practice.products.AttributesData;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class ProductTypeData {


    public String Name;
    public String Key;
    public String Description;
    public String id;

    List<AttributesData> attributes;


}
