package com.demo.practice.channels;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.channel.Channel;
import com.commercetools.api.models.channel.ChannelDraft;
import com.demo.practice.clientD.Client;
import org.springframework.beans.factory.annotation.Autowired;

public class ChannelDataProvider {


    ProjectApiRoot apiRoot = Client.createApiClient();
    public Channel createChannel(ChannelDraft channelDraft) {
        return apiRoot.channels().post(channelDraft).executeBlocking().getBody();
    }
}
