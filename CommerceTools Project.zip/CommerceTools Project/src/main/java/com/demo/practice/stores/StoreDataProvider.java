package com.demo.practice.stores;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.store.Store;
import com.commercetools.api.models.store.StoreDraft;
import com.demo.practice.clientD.Client;
import org.springframework.beans.factory.annotation.Autowired;

public class StoreDataProvider {


    ProjectApiRoot apiRoot = Client.createApiClient();

    public Store createStore(StoreDraft storeDraft) {
        return apiRoot.stores().create(storeDraft).executeBlocking().getBody();
    }
}
