package com.demo.practice.productSelections;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.product_selection.ProductSelection;
import com.commercetools.api.models.product_selection.ProductSelectionDraft;
import org.springframework.beans.factory.annotation.Autowired;

public class ProductSelectionDataProvider {

    @Autowired
    ProjectApiRoot apiRoot;


    public ProductSelection createProductSelection(ProductSelectionDraft productSelectionDraft) {
        return apiRoot.productSelections().post(productSelectionDraft).executeBlocking().getBody();
    }
}
