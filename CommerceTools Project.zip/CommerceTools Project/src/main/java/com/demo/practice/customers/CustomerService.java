package com.demo.practice.customers;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.common.BaseAddress;
import com.commercetools.api.models.common.LocalizedString;
import com.commercetools.api.models.customer.*;
import com.commercetools.api.models.type.*;
import com.demo.practice.clientD.Client;

@org.springframework.stereotype.Service
    public class CustomerService {

        static ProjectApiRoot projectApiRoot= Client.createApiClient();

        static CustomerDataProvider cdp = new CustomerDataProvider();


        public Type createCustomType(CustomTypeData customTypeData){
            // Create the FieldDefinition
            FieldDefinition fieldDefinition = FieldDefinition
                    .builder()
                    //.type(FieldTypeBuilder::numberBuilder)

                    .type(FieldType.stringBuilder().build())
                    .name(customTypeData.getFieldName())
                    //.inputHint(TypeTextInputHint.SINGLE_LINE)
                    .label(LocalizedString.ofEnglish(customTypeData.getFieldLabel()))
                    .required(customTypeData.getRequired())
                    .build();

// Create typeDraft with the FieldDefinition
            final TypeDraft typeDraft = TypeDraft
                    .builder()
                    .key(customTypeData.getTypeKey())
                    .name(LocalizedString.ofEnglish(customTypeData.getTypeName()))
                    .resourceTypeIds(ResourceTypeId.CUSTOMER)
                    .fieldDefinitions(fieldDefinition)
//                    .resourceTypeIds(List.of(ResourceTypeId.CUSTOMER))
//                    .fieldDefinitions(List.of(fieldDefinition))
                    .build();

            return cdp.createCustomType(typeDraft);

        }

        public Customer createCustomer(CustomerData data){
            CustomerDraft customerDraft =CustomerDraft
                    .builder()
                    .firstName(data.getFirstName())
                    .lastName(data.getLastName())
                    .email(data.getEmail())
                    .password(data.getPassword())
                    .externalId(data.getExternalId())
                    .companyName(data.getCompanyName())
                    .title(data.getTitle())
                    .key(data.getKey())
                    .dateOfBirth(data.getDob())
                    .addresses(BaseAddress.builder()
                            .company(data.getCompanyName())
                            .city(data.getCity())
                            .building(data.getBuilding())
                            .country(data.getCountry())
                            .state(data.getState())
                            .streetName(data.getStreetName())
                            .streetNumber(data.getStreetNumber())
                            .region(data.getRegion())
                            .postalCode(data.getPostalCode())
                            .additionalAddressInfo(data.getAdditionalAddressInfo())
                            .additionalStreetInfo(data.additionalStreetInfo)
                            .pOBox(data.getPoBox())
                            .build())
//                    .custom(customFieldsDraftBuilder -> customFieldsDraftBuilder
//                            .type(typeResourceIdentifierBuilder -> typeResourceIdentifierBuilder
//                                    .key("customer-extension"))
//                            .fields(fieldContainerBuilder -> fieldContainerBuilder
//                                    .addValue("email-preference",data.isEmailPref())))
                    .custom(customFieldsDraftBuilder -> customFieldsDraftBuilder
                            .type(typeResourceIdentifierBuilder -> typeResourceIdentifierBuilder.key(data.getCustomTypeKey()))
                            .fields(fieldContainerBuilder -> fieldContainerBuilder.addValue(data.getCustomLabel(),data.getCustomValue()))
                    )
                    .build();

            return cdp.createCustomer(customerDraft);
        }


        public  Customer  updateCustomerById(CustomerData customerData,ProjectApiRoot apiRoot){
            // Create update actions to set Custom Type
            CustomerUpdate updateActions = CustomerUpdate
                    .builder()

                    .version(customerData.getVersion())
                    .plusActions(actionBuilder ->
                            actionBuilder.setFirstNameBuilder().firstName(customerData.getFirstName()))
//               .plusActions(actionBuilder ->
//                       actionBuilder
//                               .setCustomTypeBuilder()
//                               .type(typeResourceIdentifierBuilder -> typeResourceIdentifierBuilder.id(customerData.getTypeId()))
//                               .fields(fieldContainerBuilder -> fieldContainerBuilder.addValue(customerData.getCustomFName(),customerData.isEmailPref()))

                    // **** by PUNEET ****  ////
                    // .type(builder -> builder.id("cc0afa8d-ce4d-4c35-b74b-828bbe28f4be"))
                    //  .fields(fieldContainerBuilder -> fieldContainerBuilder.addValue("email-preference" , customerData.isEmailPref()))
                    // )
                    .build();

            return apiRoot.customers().withId(customerData.getId()).post(updateActions).executeBlocking().getBody();

            //  ***** by PUNEET  ****
// Update the Customer
//       Customer customerWithCustomType = apiRoot
//               .customers()
//               .withId("3b310f52-9477-42e1-a466-61cd992ecbab")
//               .post(updateActions)
//               .executeBlocking()
//               .getBody();
            // return customerWithCustomType;
        }
//
//        CustomerUpdate customerUpdate1 = CustomerUpdate
//                .builder().version(customerUpdate.getVersion())
//                .plusActions(actionBuilder -> actionBuilder.setFirstNameBuilder().firstName(data.getFirstName()))
//                .plusActions(actionBuilder -> actionBuilder.setLastNameBuilder().lastName(data.getLastName()))
//                .plusActions(actionBuilder -> actionBuilder.setExternalIdBuilder().externalId(data.getExternalId()))
//                .plusActions(actionBuilder -> actionBuilder.changeEmailBuilder().email(data.getEmail()))
//                .plusActions(actionBuilder -> actionBuilder.setCompanyNameBuilder().companyName(data.getCompanyName()))
//                .build();
//    }


//    public Type createCustomType(TypeDraft typeDraft, FieldDefinition fieldDefinition){
//
//
//        // Create the FieldDefinition
//        FieldDefinition fieldDefinition1 = FieldDefinition
//                .builder()
//                .type(FieldType.localizedStringBuilder().build())
//                .name("shirt")
//                .inputHint(TypeTextInputHint.SINGLE_LINE)
//                .label(
//                        LocalizedString.builder().addValue("en", "Preferred shirt colours").build()
//                )
//                .required(false)
//                .build();
//
//        // Create typeDraft with the FieldDefinition
//        final TypeDraft typeDraft1 = TypeDraft
//                .builder()
//                .key("customer-preferredShirtColour")
//                .name(
//                        LocalizedString
//                                .builder()
//                                .addValue("en", "Additional field to store preferred shirt colour")
//                                .build()
//                )
//                .resourceTypeIds(List.of(ResourceTypeId.CUSTOMER))
//                .fieldDefinitions(List.of(fieldDefinition))
//                .build();
//
//        return cdp.createCustomType(typeDraft1,fieldDefinition1);
//    }


    }
