package com.demo.practice.Carts;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.cart.Cart;
import com.commercetools.api.models.cart.CartDraft;
import com.demo.practice.clientD.Client;
import org.springframework.beans.factory.annotation.Autowired;

public class CartDataProvider {
    @Autowired
    ProjectApiRoot apiRoot = Client.createApiClient();


    public Cart createCart(CartDraft draft) {
        return apiRoot.carts().post(draft).executeBlocking().getBody();
    }
}
