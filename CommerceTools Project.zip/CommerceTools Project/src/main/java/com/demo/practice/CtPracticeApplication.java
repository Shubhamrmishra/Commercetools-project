package com.demo.practice;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.project.Project;
import com.demo.practice.clientD.Client;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtPracticeApplication {

	//public static ProductController pc = new ProductController();

	static ProjectApiRoot apiRoot = Client.createApiClient();


	public static void main(String[] args) {

		SpringApplication.run(CtPracticeApplication.class, args);

		Project myProject = apiRoot
				.get()
				.executeBlocking()
				.getBody();

// Output the Project name
		System.out.println(myProject.getName());


		//ci.createCustomer();

	}



}
