package com.demo.practice.Login;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.customer.*;
import com.demo.practice.clientD.Client;
import com.demo.practice.customers.CustomerData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class LoginService {


    ProjectApiRoot projectApiRoot = Client.createApiClient();

    LoginDataProvider dataProvider = new LoginDataProvider();

    public CustomerToken createToken (@RequestBody CustomerData data){
        CustomerCreatePasswordResetToken customerCreatePasswordResetToken =
                CustomerCreatePasswordResetToken.builder().email(data.getEmail()).build();

        return dataProvider.createToken(customerCreatePasswordResetToken);

    }

    public Customer resetCustomerPassword(CustomerData data) {

        CustomerResetPassword customerResetPassword = CustomerResetPassword
                .builder()
                .tokenValue(data.getTokenValue())
                .newPassword(data.getNewPassword())
                .build();

        return dataProvider.resetCustomerPassword(customerResetPassword);

    }
    public Customer ChangeCustomerPassword(CustomerData data){
        CustomerChangePassword customerChangePassword = CustomerChangePassword
                .builder()
                .version(data.getVersion())
                .id(data.getId())
                .currentPassword(data.currentPassword)
                .newPassword(data.getNewPassword())
                .build();
        return dataProvider.ChangeCustomerPassword(customerChangePassword);

    }
    public CustomerPagedQueryResponse customfields(){
        CustomerPagedQueryResponse customerPagedQueryResponse =projectApiRoot.customers()
                .get().withWhere("")
                .executeBlocking().getBody();
        return customerPagedQueryResponse;
    }
    public CustomerSignInResult customerLogin(CustomerData data){
        CustomerSignin signin = CustomerSignin.builder()
                .email(data.getEmail())
                .password((data.getPassword()))
                .build();
        return dataProvider.customerLogin(signin);
    }

}
