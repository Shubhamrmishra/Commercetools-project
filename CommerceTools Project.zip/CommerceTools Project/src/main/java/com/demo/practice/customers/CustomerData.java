package com.demo.practice.customers;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;


@Getter
@Setter
public class CustomerData {


    public String key;
    public LocalDate dob;
    public String firstName;
    public String lastName;
    public String email;
    public String password;
    public String externalId;
    public String companyName;
    public String Title;
    public String customFName;
    public boolean emailPref;
    public long version;
    public String tokenValue;
    public String newPassword;
    public String currentPassword;
    public String Id;
    public String typeId;

    /// Address draft

    public String addressType;
    public String streetNumber;
    public String streetName;
    public String building;
    public String apartment;
    public String poBox;
    public String City;
    public String postalCode;
    public String region;
    public  String state;
    public String Country;
    public String additionalStreetInfo;
    public String additionalAddressInfo;


    /// Custome fields value

    public String customTypeKey;
    public String customLabel;
    public String customValue;
}
