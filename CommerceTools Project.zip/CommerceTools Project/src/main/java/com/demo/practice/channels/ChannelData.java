package com.demo.practice.channels;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ChannelData {
    public String channelKey;
    public String Name;
    public String Description;
    public String Roles;
    public String Address;
    public String streetName;
    public String State;
    public String Phone;
    public String Company;
    public String City;
    public String Country;
    public String postalCode;
    public String Apartment;
    public String Building;
    public String Email;
    public String Mobile;
    public String Department;

}
