package com.demo.practice.Login;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.customer.*;
import com.demo.practice.clientD.Client;
import org.springframework.beans.factory.annotation.Autowired;

public class LoginDataProvider {


    ProjectApiRoot projectApiRoot = Client.createApiClient();

    public CustomerToken createToken(CustomerCreatePasswordResetToken customerCreatePasswordResetToken) {
        return projectApiRoot.customers().passwordToken().post(customerCreatePasswordResetToken).executeBlocking().getBody();
    }

    public Customer resetCustomerPassword(CustomerResetPassword customerResetPassword) {
        return projectApiRoot.customers().passwordReset().post(customerResetPassword).executeBlocking().getBody();
    }

    public Customer ChangeCustomerPassword(CustomerChangePassword customerChangePassword) {
        return projectApiRoot.customers().password().post(customerChangePassword).executeBlocking().getBody();
    }


    public CustomerSignInResult customerLogin(CustomerSignin signin) {
        return projectApiRoot.login().post(signin).executeBlocking().getBody();
    }
}
