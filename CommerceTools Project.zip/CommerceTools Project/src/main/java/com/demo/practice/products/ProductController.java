package com.demo.practice.products;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.product.Product;
import com.commercetools.api.models.product.ProductPagedQueryResponse;
import com.commercetools.api.models.product_selection.ProductSelection;
import com.commercetools.api.models.product_type.ProductType;
import com.commercetools.api.models.store.Store;
import com.commercetools.api.models.tax_category.TaxCategory;
import com.demo.practice.channels.ChannelService;
import com.demo.practice.clientD.Client;
import com.demo.practice.productSelections.ProductSelectionData;
import com.demo.practice.productSelections.ProductSelectionService;
import com.demo.practice.stores.StoreData;
import com.demo.practice.stores.StoreService;
import com.demo.practice.taxs.TaxData;
import com.demo.practice.taxs.TaxService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
public class ProductController {

    ProjectApiRoot projectApiRoot = Client.createApiClient();

    @Autowired
    ProductService productService;
    @Autowired
    ChannelService channelService;
    @Autowired
    TaxService taxService;
    @Autowired
    StoreService storeService;
    @Autowired
    ProductSelectionService selectionService;


    @PostMapping("/productType")
    public ProductType createProductType(@RequestBody ProductTypeData productTypeData){
       return productService.createProductType(productTypeData);
    }
    @PostMapping("/createProduct")
    public Product createProduct(@RequestBody ProductData productData ){
        return productService.createProduct(productData);
    }
    @GetMapping("/product")
    ProductPagedQueryResponse GetAllroducts(){
        return projectApiRoot.products().get().executeBlocking().getBody();
    }
    @GetMapping("/product/{id}")
    Product productGetById(@PathVariable String id){
        return projectApiRoot.products().withId(id).get().executeBlocking().getBody();
    }
    @GetMapping("/product/Sku/{id}")
    public String getSku(@PathVariable String id){
        return projectApiRoot.products().withId(id).get().executeBlocking().getBody().getMasterData().getCurrent().getMasterVariant().getSku();
    }

    @GetMapping("/product/attribute/{id}")
    public List getAttribute(@PathVariable String id){
        return projectApiRoot.products().withId(id).get().executeBlocking().getBody().getMasterData().getCurrent().getMasterVariant().getAttributes();
    }


    @DeleteMapping("/delete-product/{id}")
    public Product deleteProductById(@PathVariable String id){
        return projectApiRoot.products().withId(id).delete(1).executeBlocking().getBody();
    }
    @PostMapping("/update/{id}")
    public Product updateProducts(@RequestBody ProductData productData,@PathVariable String id){
        return productService.updateProducts(productData,id);
    }

    @GetMapping("/product/price/{id}")
    public Long getPrice(@PathVariable String id){
       return projectApiRoot.products().withId(id).get().executeBlocking().getBody()
               .getMasterData().getCurrent().getMasterVariant().getPrices().get(1).getValue().getCentAmount();
    }


}
