package com.demo.practice.products;

import com.commercetools.api.models.product.Attribute;
import com.commercetools.api.models.product_type.AttributeConstraintEnum;
import com.commercetools.api.models.product_type.AttributeType;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AttributesData {
    public String label;
    public String attributeName;
    public AttributeType attributeType;
    public Boolean isRequired;
    public Boolean isSearchable;
    public AttributeConstraintEnum attributeConstraint;
    public String inputHint;
    public String inputTip;


}
