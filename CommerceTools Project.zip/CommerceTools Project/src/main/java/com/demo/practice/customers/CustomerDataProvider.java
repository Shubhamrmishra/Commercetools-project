package com.demo.practice.customers;


import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.customer.*;
import com.commercetools.api.models.type.Type;
import com.commercetools.api.models.type.TypeDraft;
import com.demo.practice.clientD.Client;

public class CustomerDataProvider {

    ProjectApiRoot projectApiRoot= Client.createApiClient();

    public Customer createCustomer(CustomerDraft customerDraft) {
        return projectApiRoot.customers().post(customerDraft).executeBlocking().getBody().getCustomer();
    }

//    public Type createCustomType(TypeDraft typeDraft1, FieldDefinition fieldDefinition1) {
//        return projectApiRoot.types().post(typeDraft1).executeBlocking().getBody();
//    }

    public Type createCustomType(TypeDraft typeDraft) {
        return projectApiRoot.types().post(typeDraft).executeBlocking().getBody();

    }
}

