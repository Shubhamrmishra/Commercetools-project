package com.demo.practice.taxs;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.tax_category.TaxCategory;
import com.commercetools.api.models.tax_category.TaxCategoryDraft;
import com.demo.practice.clientD.Client;
import org.springframework.beans.factory.annotation.Autowired;

public class TaxDataProvider {

    ProjectApiRoot apiRoot = Client.createApiClient();

    public TaxCategory createTax(TaxCategoryDraft categoryDraft) {
        return apiRoot.taxCategories().post(categoryDraft).executeBlocking().getBody();
    }
}
