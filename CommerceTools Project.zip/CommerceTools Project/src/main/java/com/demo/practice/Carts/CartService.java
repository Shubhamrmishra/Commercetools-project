package com.demo.practice.Carts;

import com.commercetools.api.models.cart.*;
import com.demo.practice.Carts.CartData;
import com.demo.practice.Carts.CartDataProvider;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CartService {


    CartDataProvider cd = new CartDataProvider();
//    public Cart createCart(CartData cartData, lineItemsData itemsData){
//        CartDraft cartDraft = CartDraft.builder()
//                .currency(cartData.getCurrency())
//               // .lineItems(LineItemDraft.builder().sku(cartData.getSku()).build())
//                .lineItems(LineItemDraft.builder()
//                        //.productId(cartData.getProductId())
//                        .sku(itemsData.getSku())
//                        .build())
//                .taxMode(TaxMode.DISABLED)
//                .build();
//
//        return cd.createCart(cartDraft);
//    }

    public Cart createCart(CartData cartData){

        List<LineItemDraft> listLineItems = cartData.getLineItems().stream()
                .map(LineItem -> {
                    return LineItemDraft.builder().sku(LineItem.getSku()).build();
                }
        ).collect(Collectors.toList());


        CartDraft draft = CartDraft
                .builder()
                .currency(cartData.getCurrency())
                .lineItems(listLineItems)
                .taxMode(cartData.getTaxMod())
                .customerId(cartData.getCustomerId())

                .build();

        return cd.createCart(draft);
    }
}
