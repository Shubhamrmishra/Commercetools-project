package com.demo.practice.stores;

import com.commercetools.api.models.channel.ChannelResourceIdentifier;
import com.commercetools.api.models.common.LocalizedString;
import com.commercetools.api.models.store.Store;
import com.commercetools.api.models.store.StoreDraft;
import com.commercetools.api.models.store_country.StoreCountry;
import com.demo.practice.products.ProductDataProvider;
import org.springframework.stereotype.Service;

@Service
public class StoreService {
   StoreDataProvider sdp = new StoreDataProvider();
    public Store createStore(StoreData storeData){
        StoreDraft storeDraft = StoreDraft.builder()
                .key(storeData.getStoreKey()).name(LocalizedString.ofEnglish(storeData.getStoreName()))
                .countries(StoreCountry.builder().code(storeData.getCountry()).build())
                .distributionChannels(ChannelResourceIdentifier.builder().id(storeData.getChannelId()).build())
                .languages(storeData.getLanguage())
//                .plusProductSelections(ProductSelectionSettingDraft.builder()
//                        .productSelection(ProductSelectionResourceIdentifier.builder()
//                                .id(storeData.getProductSelection()).build()).build())
                .build();
        return sdp.createStore(storeDraft);
    }

}
