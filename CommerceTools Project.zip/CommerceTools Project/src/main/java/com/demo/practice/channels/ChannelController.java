package com.demo.practice.channels;

import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.channel.Channel;
import com.commercetools.api.models.channel.ChannelPagedQueryResponse;
import com.demo.practice.clientD.Client;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/channel")
public class ChannelController {

    @Autowired
    ProjectApiRoot apiRoot = Client.createApiClient();

    @Autowired
    ChannelService channelService = new ChannelService();
    @PostMapping("/create")
    public Channel createChannel(@RequestBody ChannelData channelData){
        return channelService.createChannel(channelData);
    }
    @GetMapping("/get")
    public ChannelPagedQueryResponse getAllChannels(){
        return apiRoot.channels().get().executeBlocking().getBody();
    }
    @GetMapping("/get/{id}")
    public Channel getChannelByID(@PathVariable String id){
        return apiRoot.channels().withId(id).get().executeBlocking().getBody();
    }
    @DeleteMapping("/delete/{id}/{ver}")
    public Channel deleteChannelByID(@PathVariable String id, @PathVariable int ver){
        return apiRoot.channels().withId(id).delete().withVersion(ver).executeBlocking().getBody();
    }
}
