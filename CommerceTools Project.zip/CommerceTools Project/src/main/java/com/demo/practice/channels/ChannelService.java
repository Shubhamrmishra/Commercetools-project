package com.demo.practice.channels;

import com.commercetools.api.models.channel.Channel;
import com.commercetools.api.models.channel.ChannelDraft;
import com.commercetools.api.models.channel.ChannelRoleEnum;
import com.commercetools.api.models.common.LocalizedString;
import com.demo.practice.channels.ChannelData;
import com.demo.practice.products.ProductDataProvider;
import org.springframework.stereotype.Service;

@Service
public class ChannelService {

   ChannelDataProvider cdp = new ChannelDataProvider();

    public Channel createChannel(ChannelData channelData){
        ChannelDraft channelDraft = ChannelDraft.builder()
                .name(LocalizedString.ofEnglish(channelData.getName()))
                .key(channelData.getChannelKey())
                .roles(ChannelRoleEnum.findEnum(channelData.getRoles()))
                .description(LocalizedString.ofEnglish(channelData.getDescription()))
                .address(baseAddressBuilder -> baseAddressBuilder.streetName(channelData.getStreetName())
                        .company(channelData.getCompany()).state(channelData.getState())
                        .email(channelData.getEmail()).mobile(channelData.getMobile()).department(channelData.getDepartment())
                        .phone(channelData.getPhone()).city(channelData.getCity()).country(channelData.getCountry())
                        .postalCode(channelData.getPostalCode()).apartment(channelData.getApartment()).building(channelData.getBuilding()))
                .build();
        return cdp.createChannel(channelDraft);
    }
}