package com.demo.practice.productSelections;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ProductSelectionData {
    public  String name;
    public String key;

}
