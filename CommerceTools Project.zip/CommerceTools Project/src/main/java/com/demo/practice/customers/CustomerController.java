package com.demo.practice.customers;


import com.commercetools.api.client.ProjectApiRoot;
import com.commercetools.api.models.customer.*;
import com.commercetools.api.models.type.Type;
import com.demo.practice.clientD.Client;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j

@RequestMapping("/customer")
public class CustomerController {


    ProjectApiRoot projectApiRoot= Client.createApiClient();
    @Autowired
    CustomerService service ;

    @PostMapping("/create")
    public Customer createCustomer(@RequestBody CustomerData customerData) {
       // log.info("customerData={}", customerData.isEmailPref());
        return service.createCustomer(customerData);
    }

    @PostMapping("/update/{id}")
    public Customer updateCustomerById(@PathVariable String id,@RequestBody CustomerData customerData){
        return service.updateCustomerById(customerData,projectApiRoot);
    }

    @GetMapping("/all")
    CustomerPagedQueryResponse customerlimitCustomer(@RequestParam(required = true, defaultValue = "25") int limits){
        return projectApiRoot.customers().get().withLimit(limits).executeBlocking().getBody();
    }
    @GetMapping("/get/{id}")
    Customer customerById(@PathVariable String id){
        return projectApiRoot.customers().withId(id).get().executeBlocking().getBody();
    }

    @DeleteMapping("/delete/{id}/{ver}")
    Customer customerdeleteById(@PathVariable String id,@PathVariable int ver)
    {
        return projectApiRoot.customers().withId(id).delete().withVersion(ver).executeBlocking().getBody();
    }
    @PostMapping("/create-custom")
    public Type createCustomType(@RequestBody CustomTypeData customTypeData) {
        return service.createCustomType(customTypeData);
    }
    @GetMapping("/custom-fields")
    public CustomerPagedQueryResponse customfields(@RequestParam String where){
        return projectApiRoot.customers().get().withWhere(where).executeBlocking().getBody();
    }

}

